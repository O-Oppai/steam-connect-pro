document.addEventListener('DOMContentLoaded', () => {

    /* ===============================
       Dropdown System
    =============================== */

    document.querySelectorAll('.dropdown').forEach(drop => {
        const trigger = drop.querySelector('.dropdown-text, .btn-sell');
        const menu = drop.querySelector('.dropdown-menu');
        if (!trigger || !menu) return;

        trigger.addEventListener('click', e => {
            if (window.innerWidth <= 991) {
                e.preventDefault();
                drop.classList.toggle('open');
            }
        });

        drop.addEventListener('mouseenter', () => {
            if (window.innerWidth > 991) drop.classList.add('open');
        });

        drop.addEventListener('mouseleave', () => {
            if (window.innerWidth > 991) drop.classList.remove('open');
        });
    });

    document.addEventListener('click', e => {
        document.querySelectorAll('.dropdown').forEach(drop => {
            if (!drop.contains(e.target)) drop.classList.remove('open');
        });
    });


    /* ===============================
       Prevent Guest Sell
    =============================== */

    const sellBtn = document.querySelector('.sell-account-btn');

    if (sellBtn) {
        sellBtn.addEventListener('click', function (e) {

            if (!document.body.classList.contains('logged-in')) {
                e.preventDefault();
                showLoginWarning();
            }

        });
    }


    /* ===============================
       AJAX Logout (VPN Safe)
    =============================== */

    const logoutBtn = document.getElementById('gamebani-logout-btn');

    if (logoutBtn && typeof GAMEBANI_LOGOUT !== 'undefined') {

        logoutBtn.addEventListener('click', function (e) {

            e.preventDefault();

            logoutBtn.classList.add('loading');

            fetch(GAMEBANI_LOGOUT.ajax_url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    action: 'gamebani_logout',
                    nonce: GAMEBANI_LOGOUT.nonce
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.data.redirect) {
                    window.location.href = data.data.redirect;
                } else {
                    location.reload();
                }
            })
            .catch(() => location.reload());
        });
    }

});


/* ===============================
   Login Warning UI
=============================== */

function showLoginWarning() {

    if (document.querySelector('.login-warning')) return;

    const warning = document.createElement('div');
    warning.className = 'login-warning';
    warning.innerHTML = `
        لطفا ابتدا با دکمه 
        <span class="steam-highlight">ورود/ثبت نام</span>
        وارد سایت شوید.
    `;

    document.body.appendChild(warning);

    setTimeout(() => warning.classList.add('active'), 50);

    setTimeout(() => {
        warning.classList.remove('active');
        setTimeout(() => warning.remove(), 400);
    }, 5000);
}
