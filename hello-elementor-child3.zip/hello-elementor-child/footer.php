<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<footer class="gaming-footer">
	<div class="gaming-footer-container">

		<!-- ستون 1 -->
		<div class="footer-col">
			<h3>درباره ما</h3>
			<p>
				فروش و خرید اکانت بازی با امنیت بالا، تحویل سریع و پشتیبانی واقعی.
			</p>
		</div>

		<!-- ستون 2 -->
		<div class="footer-col">
			<h3>دسترسی سریع</h3>
			<ul>
				<li><a href="/shop">فروشگاه</a></li>
				<li><a href="/sell-account">فروش اکانت</a></li>
				<li><a href="/support">پشتیبانی</a></li>
				<li><a href="/blog">آموزش‌ها</a></li>
			</ul>
		</div>

		<!-- ستون 3 -->
		<div class="footer-col footer-enamad">
			<h3>اعتماد شما</h3>

			<a referrerpolicy='origin' target='_blank' href='https://trustseal.enamad.ir/?id=628470&Code=Tg6IGFYOjonGo4vAWb2g1PdXHV6jq4p3'><img referrerpolicy='origin' src='https://trustseal.enamad.ir/logo.aspx?id=628470&Code=Tg6IGFYOjonGo4vAWb2g1PdXHV6jq4p3' alt='' style='cursor:pointer' code='Tg6IGFYOjonGo4vAWb2g1PdXHV6jq4p3'></a>

		</div>

	</div>

	<div class="gaming-footer-bottom">
		© <?php echo date('Y'); ?> <?php bloginfo('name'); ?> — تمام حقوق محفوظ است
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
