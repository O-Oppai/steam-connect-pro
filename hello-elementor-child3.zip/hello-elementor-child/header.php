<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$viewport_content = apply_filters( 'hello_elementor_viewport_content', 'width=device-width, initial-scale=1' );
$enable_skip_link = apply_filters( 'hello_elementor_enable_skip_link', true );
$skip_link_url    = apply_filters( 'hello_elementor_skip_link_url', '#content' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="<?php echo esc_attr( $viewport_content ); ?>">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="gaming-header">
	<div class="gaming-container">

		<!-- Right -->
		<div class="gaming-right">

			<div class="gaming-logo">
				<a href="<?php echo esc_url( home_url('/') ); ?>">
					<?php bloginfo('name'); ?>
				</a>
			</div>

			<div class="dropdown hover-safe">
				<span class="dropdown-text">
					خرید اکانت <span class="caret">▾</span>
				</span>
				<div class="dropdown-menu">
					<a href="https://gamebani.ir/buy-steam-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/steam.png"> Steam
					</a>
					<a href="https://gamebani.ir/buy-arknight-endfield-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/arknight-endfield.png"> Arknight Endfield
					</a>
					<a href="https://gamebani.ir/buy-honkai-star-rail-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/honkai-star-rail.png"> Honkai Star Rail
					</a>
					<a href="https://gamebani.ir/buy-zenless-zone-zero-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/zenless-zon-zero.png"> Zenless Zone Zero
					</a>
					<a href="https://gamebani.ir/buy-wuthering-waves-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/wuthering-waves.png"> Wutering Waves
					</a>

				</div>
			</div>

			<div class="header-links">
				<a href="https://t.me/gamebani">پشتیبانی</a>
				<a href="#">آموزش سایت</a>
			</div>

		</div>

		<!-- Left -->
		<div class="gaming-left">

			<?php if ( is_user_logged_in() ) : 
				$current_user = wp_get_current_user();
				$avatar_url = get_user_meta( $current_user->ID, 'steam_avatar', true );

				if ( empty( $avatar_url ) ) {
					$avatar_url = get_avatar_url( $current_user->ID, ['size' => 36] );
				}
			?>

				<!-- Sell Dropdown -->
				<div class="dropdown hover-safe user-dropdown">
					<button class="btn-sell">
						فروش اکانت ▾
					</button>
					<div class="dropdown-menu dropdown-left">
						<a href="https://gamebani.ir/sell-steam-account/">
							<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/steam.png"> Steam
						</a>
						<a href="https://gamebani.ir/sell-arknight-endfield-account/">
							<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/arknight-endfield.png"> Arknight Endfield
						</a>
						<a href="https://gamebani.ir/sell-honkai-star-rail-account/">
							<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/honkai-star-rail.png"> Honkai Star Rail
						</a>
						<a href="https://gamebani.ir/sell-zenless-zone-zero-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/zenless-zon-zero.png"> Zenless Zone Zero
					</a>
					<a href="https://gamebani.ir/sell-wuthering-waves-account/">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/wuthering-waves.png"> Wutering Waves
					</a>

					</div>
				</div>

				<!-- Notifications + Avatar Inline -->
				<div class="user-header-inline" style="display:flex; align-items:center; gap:12px;">
				<div class="header-notifications">
						<?php echo do_shortcode('[gud_verification_alert]'); ?>
					</div>

					<!-- Plugin Notifications -->
					<div class="header-notifications">
						<?php echo do_shortcode('[scp_notifications]'); ?>
					</div>

					<!-- Steam Status Messages (Sticky) -->
					<div class="header-steam-messages">
						<?php
						$steam_message = '';
						$steam_class   = '';
						$get = array_map('sanitize_text_field', wp_unslash($_GET));

						if ( isset($get['steam_already_registered']) && $get['steam_already_registered'] === '1' ) {
							$steam_message = '❌ این اکانت استیم از قبل در سایت ثبت شده است. جهت راهنمایی لطفاً به پشتیبانی پیام دهید.';
							$steam_class = 'scp-error';
						}
						elseif ( isset($get['steam_connected']) && $get['steam_connected'] === '1' ) {
							$steam_message = '✅ اتصال به استیم با موفقیت انجام شد.';
							$steam_class = 'scp-success';
						}
						elseif ( isset($get['steam_login_success']) && $get['steam_login_success'] === '1' ) {
							$steam_message = '🎉 ورود با استیم با موفقیت انجام شد.';
							$steam_class = 'scp-success';
						}
						elseif ( isset($get['steam_register_success']) && $get['steam_register_success'] === '1' ) {
							$steam_message = '🎉 ثبت‌نام با استیم با موفقیت انجام شد.';
							$steam_class = 'scp-success';
						}
						elseif ( isset($get['steam_disconnected']) && $get['steam_disconnected'] === '1' ) {
							$steam_message = '⚠️ اتصال استیم با موفقیت قطع شد.';
							$steam_class = 'scp-warning';
						}
						elseif ( isset($get['steam_error']) && $get['steam_error'] === '1' ) {
							$steam_message = '❌ خطایی در ارتباط با استیم رخ داد. لطفاً دوباره تلاش کنید.';
							$steam_class = 'scp-error';
						}

						if ( $steam_message ) :
						?>
							<div id="scp-sticky-error" class="<?php echo esc_attr($steam_class); ?>" role="alert">
								<?php echo esc_html( $steam_message ); ?>
							</div>
						<?php endif; ?>
					</div>

					<!-- User Dropdown -->
					<div class="dropdown hover-safe user-dropdown">
						<span class="dropdown-text user-info">
							<img src="<?php echo esc_url( $avatar_url ); ?>" alt="Avatar" class="user-avatar">
							<?php echo esc_html( $current_user->display_name ); ?>
							<span class="caret">▾</span>
						</span>

						<div class="dropdown-menu dropdown-left">
							<a href="https://gamebani.ir/profile/">
								<i class="dashicons dashicons-admin-users"></i> پروفایل
							</a>

							<a href="https://gamebani.ir/my-accounts/">
 								<i class="dashicons dashicons-portfolio"></i> آکانت های من
							</a>

							<a href="https://gamebani.ir/settings/">
								<i class="dashicons dashicons-admin-generic"></i> تنظیمات
							</a>

							<a href="https://gamebani.ir/connections/">
								<i class="dashicons dashicons-admin-network"></i> اتصال‌ها
							</a>

							<a href="https://gamebani.ir/chat/">
								<i class="dashicons dashicons-format-chat"></i> چت‌های من
							</a>

							<a href="https://gamebani.ir/my-friends/">
								<i class="dashicons dashicons-groups"></i> دوستان من
							</a>

							<a href="#" id="gamebani-logout-btn">
								<i class="dashicons dashicons-dismiss"></i> خروج
							</a>

						</div>
					</div>

				</div>

			<?php else : ?>

				<div class="guest-actions">

					<div class="steam-login-btn">
						<?php echo do_shortcode('[gaming_auth]'); ?>
					</div>

					<div class="dropdown hover-safe">
						<button class="sell-account-btn">فروش اکانت ▾</button>
					</div>

				</div>

			<?php endif; ?>

		</div>

	</div>
</header>
